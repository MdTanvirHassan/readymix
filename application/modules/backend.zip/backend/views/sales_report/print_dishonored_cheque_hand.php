
<style>
    #content-table{
        line-height: 18px !important;
    }
    .table{
        
    }
    @page {
    size: auto;   /* auto is the initial value */
    margin-top: 10px;  /* this affects the margin in the printer settings */
    margin-bottom: 0;
}
</style>



 
<div style="padding:0" class="col-md-10 col-md-offset-1">
   
            
    <h2 style=" font-size:18px;text-align: center;">Karim Asphalt & Ready Mix Ltd.</h>
    <p style=" text-align: center;margin-top:-2px;margin-bottom:5px;">Dishonored Cheque/PO/BG At Hand</p> 

    
    
       <table class="table table-bordered table-hover table-striped" style="margin:0 auto;">
          
            <thead>
                <tr></tr>
                                
                                <tr>
                                   <th style="border-left:1px solid;border-top:1px solid;width:10px;">SL</th>                      
                                   <th style="border-left:1px solid;border-top:1px solid;width:150px;">Customer Name</th> 
                                   <th style="border-left:1px solid;border-top:1px solid;width:150px;">Product Type</th>
                                   <th style="border-left:1px solid;border-top:1px solid;width:150px;">Collection Method</th>
                                   <th style="border-left:1px solid;border-top:1px solid;width:40px;">Pdc/Lc/Bg No.</th>
                                   
                                   <th style="border-left:1px solid;border-top:1px solid;width:150px;">Dishonor Date 1</th>
                                   <th style="border-left:1px solid;border-top:1px solid;width:150px;">Dishonor Date 2</th>
                                   <th style="border-left:1px solid;border-top:1px solid;width:150px;">Dishonor Date 3</th>
                                  
                                   <th style="border-left:1px solid;border-top:1px solid;border-right:1px solid;width:100px;">Value</th>
                                </tr>
                            </thead>
                             <tbody>
                                     
                                                
                                      <?php if(!empty($orders)){
                                                           
                                                     ?>
                                                            <?php 
                                                            $i=0;
                                                            $total=0;
                                                            foreach($orders as $order){ 
                                                                $i++;
                                                                $total=$total+$order['amount'];
                                                                ?> 
                                                                    
                                                                     <tr>
                                                                       <td style="border-left:1px solid;border-top:1px solid;text-align:center;"><?php echo $i; ?></td>
                                                                        
                                                                       
                                                                       <td style="border-left:1px solid;border-top:1px solid;"><?php if(!empty($order['c_name'])) echo $order['c_name']; ?></td>
                                                                       <td style="border-left:1px solid;border-top:1px solid;"><?php if(!empty($order['category_name'])) echo $order['category_name']; ?></td>
                                                                       <td style="border-left:1px solid;border-top:1px solid;"><?php if(!empty($order['collection_method'])) echo $order['collection_method']; ?></td>
                                                                       
                                                                       <td style="border-left:1px solid;border-top:1px solid;text-align:center;"><?php if(!empty($order['no'])) echo $order['no']; ?></td>
                                                                       <td style="border-left:1px solid;border-top:1px solid;text-align:center;"><?php if(!empty($order['dishonored1'])) echo date('d-m-Y',strtotime($order['dishonored1'])); ?></td>
                                                                       <td style="border-left:1px solid;border-top:1px solid;text-align:center;"><?php if(!empty($order['dishonored2'])) echo date('d-m-Y',strtotime($order['dishonored2'])); ?></td>
                                                                       <td style="border-left:1px solid;border-top:1px solid;text-align:center;"><?php if(!empty($order['dishonored3'])) echo date('d-m-Y',strtotime($order['dishonored3'])); ?></td>
                                                                       
                                                                       <td style="border-left:1px solid;border-top:1px solid;border-right:1px solid;text-align:right;"><?php if(!empty($order['amount'])) echo number_format($order['amount'],2); ?></td>


                                                                    </tr>
                                                            <?php } ?>
                                                                    <tr>
                                                                        <td colspan="8" style="text-align:right;border-left:1px solid;border-top:1px solid;border-bottom:1px solid;">Total</td>
                                                                        <td  style="text-align:right;border-left:1px solid;border-top:1px solid;border-right:1px solid;border-bottom:1px solid;"><?php echo number_format($total,2); ?></td>
                                                                    </tr>
                                               
                                     <?php }else{ ?>
                                            <tr>
                                                <td colspan="11" style="text-align:center;border-left:1px solid;border-top:1px solid;border-right:1px solid;border-bottom:1px solid;">No Data Found</td>
                                            </tr>
                                     <?php } ?>
                            </tbody>
            
                            
                       
                                                                           
                                                    

        </table>
   
    
</div>
<div class="clearfix"></div>