 <div class="right_col" style="background-color: #f1f1f1;padding-bottom:20px;">
            <h2 style="text-align:center; ">Customers Information Entry/Edit Session</h2>
            <hr>
            <form>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Customer Code :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Contact Parson :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Contact Address :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Land Phone :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Mobile Phone :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Fax.No :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Email :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Website :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault"> Status :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            
                        </div>
                    </div>
                </div>
                
                <hr>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-default button">ADD</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-primary button">Search</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-success button">VIEW</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-info button">CLEAR</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning button">SAVE</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn  btn-danger button">EXIT</button>
                    </div>
                </div>
            </form>
        </div>