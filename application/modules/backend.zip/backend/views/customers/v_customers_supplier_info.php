<div class="right_col" style="background-color: #f1f1f1;padding-bottom:20px;">
            <h2 style="text-align:center; ">Supplier/Customer's Information Entry/Edit Session</h2>
            <hr>
            <form>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Local/Foreign :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Supplier Code :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Contact person  :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Contact Address :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Land Phone :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Mobile Phone :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">EMAIL :</label></div>
                            <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Fax Number:</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">Status :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group row">
                            <div class="col-sm-4 col-md-5  labeltext"><label for="inputdefault">WEBSITE :</label></div>
                             <div class="col-sm-8 col-md-7 "><input class="form-control" id="inputdefault" type="text"></div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-2">
                        <button type="button" class="btn btn-default button">ADD</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-primary button">FIND</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-success button">VIEW</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-info button">CLEAR</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn btn-warning button">SAVE</button>
                    </div>
                    <div class="col-md-2">
                        <button type="button" class="btn  btn-danger button">EXIT</button>
                    </div>
                </div>
            </form>
        </div>
